"""
Pickleball Session Manager - Python Port
"""

__version__ = "0.1.0"
